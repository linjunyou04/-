id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

Running_bin="${MODPATH}/mod/ads_monitor/ads_monitor"
Running_config="${MODPATH}/mod/ads_monitor/ads_monitor.prop"

test ! -f "${Running_bin}" && exit 0
source $MODPATH/mod/util_functions.sh

wait_until_login() {
	# in case of /data encryption is disabled
	while [ "$(getprop sys.boot_completed)" != "1" ]; do
		sleep 1
	done
	# we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
	a="0"
	local test_file="/data/media/0/Android/data"
	while [ ! -e "${test_file}" ]; do
		a="$(($a + 1))"
		test "$a" = "3" && break
		sleep 3m
	done
}

wait_until_login

if ! dumpsys -l | grep 'cpuinfo' >/dev/null 2>&1 ;then
	Log_10007_dmesg "@10007 dumpsys service cpuinfo does not exist" "E"
else
a="1"
until $(dumpsys cpuinfo | grep 'ads_monitor' >/dev/null 2>&1)
do
	test "${a}" = "3" && break
	a="$(($a + 1))"
	sleep 5m
done
Check_cpuinfo="$(dumpsys cpuinfo | grep -Eo '[0-9]{1,3}(\.[0-9])?%[[:space:]]+[0-9]{1,6}\/ads_monitor' | sed -E 's|[[:space:]][0-9]{1,6}/ads_monitor||g')"
case "${Check_cpuinfo}" in
0.[0-9]%|0%)
	echo "正常"
;;
[0-9]%|[0-9].[0-9]%)
	echo "占用过大"
;;
[0-9][0-9]%|[0-9][0-9].[0-9]%)
	killall -9 ads_monitor >/dev/null 2>&1
	echo "异常占用！"
	Log_10007_dmesg "@10007 ads_monitor Running wrong" "E"
;;
esac
fi

