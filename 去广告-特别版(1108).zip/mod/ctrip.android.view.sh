id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh


find /data/user/*/ctrip.android.view /data/data/ctrip.android.view /data/media/*/Android/data/ctrip.android.view -name "CTAD*" -type d 2>/dev/null | while read adfile
do
	mkdir_file $adfile 2>/dev/null 
done


function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
#振动权限
VIBRATE
#写入日历
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
#身体传感器
ACTIVITY_RECOGNITION
BODY_SENSORS
#系统浮窗
SYSTEM_ALERT_WINDOW
#音量控制
TAKE_AUDIO_FOCUS
AUDIO_MEDIA_VOLUME
#手机信息
READ_PHONE_STATE
"
for ops in $list 
do
	echo "${ops}" | grep -q "^#" && continue
	cmd appops set $package $ops $action
done
}

#deny_appops "ctrip.android.view" "ignore"
