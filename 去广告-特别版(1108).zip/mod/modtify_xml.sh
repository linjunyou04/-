files=(
#小米天气
/data/user/*/com.miui.weather2/shared_prefs/com.miui.weather2_preferences.xml
/data/user/*/com.android.calendar/shared_prefs/com.android.calendar_preferences.xml
/data/user/*/com.miui.cleanmaster/shared_prefs/com.miui.cleanmaster_preferences.xml
)

function modtify_ad_xml(){
local target_content="${2}"
local target_file="${1}"
test ! -f "${target_file}" -o "${target_content}" = "" && return 0
sed -i "s/name=\"${target_content}\".*value=\".*\"/name=\"${target_content}\" value=\"false\"/g" "${target_file}"
}


for i in ${files[@]}
do
	modtify_ad_xml "${i}" "key_information_setting_wlan"
	modtify_ad_xml "${i}" "key_information_settings"
	modtify_ad_xml "${i}" "key_content_promotion"
	modtify_ad_xml "${i}" "key_information_setting_wlan"
	modtify_ad_xml "${i}" "key_video_settings"
	modtify_ad_xml "${i}" "key_information_setting_close"
	modtify_ad_xml "${i}" "key_information_setting_wlan"
done
