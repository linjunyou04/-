#/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

#查找浏览器BrowserMetrics缓存文件夹的函数
function clear_BrowserMetrics_dir() {
	find /data/user /data/data /data/media -iname "*BrowserMetrics*" -type d 2>/dev/null | while read BrowserMetrics ;do
		X_file $BrowserMetrics 2>/dev/null
#		echo "$BrowserMetrics" >>$MODPATH/Browser.log
	done
}

#查找浏览器BrowserMetrics缓存文件的函数
function clear_BrowserMetrics_file() {
	find /data/user /data/data /data/media -iname "*BrowserMetrics*" -type f 2>/dev/null | while read BrowserMetricsfile ;do
		rm -rf $BrowserMetricsfile 2>/dev/null
#		echo "$BrowserMetricsfile" >>$MODPATH/Browser.log
	done
}

function recovery_BrowserMetrics_file() {
	find /data/user /data/data /data/media -iname "*BrowserMetrics*" 2>/dev/null | while read BrowserMetricsfile ;do
		RE_file $BrowserMetricsfile 2>/dev/null
#		echo "$BrowserMetricsfile" >>$MODPATH/Browser.log
	done
}

if test $(show_value "chattr锁定") == 是 ;then
#运行删除文件
	clear_BrowserMetrics_dir
	clear_BrowserMetrics_file
else 
	recovery_BrowserMetrics_file
fi