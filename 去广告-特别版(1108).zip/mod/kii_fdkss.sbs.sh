id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"
export PATH="/system/bin:$MODPATH/busybox:$PATH"

function disable_apps(){
local package="${1}"
test "${2}" = "" && return 0
if test "${2}" = "disable" ;then
	pm clear "${package}" >/dev/null 2>&1
	pm disable "${package}" >/dev/null 2>&1
	pm hide "${package}" >/dev/null 2>&1
else
	pm unhide "${package}" >/dev/null 2>&1
	pm enable "${package}" >/dev/null 2>&1
fi
}

function is_system_path(){
local package_name="$1"
if test "$(dumpsys package "$package_name" 2>/dev/null | grep -i ".*path.*/system/")" != "";then
	echo "true"
	#return 0
else
	echo "false"
	#return 1
fi
}

iptables -D OUTPUT -m string --string "fdkss.sbs" --algo bm --to 65535 -j DROP >/dev/null 2>&1
iptables -A OUTPUT -m string --string "fdkss.sbs" --algo bm --to 65535 -j DROP

if [[ "`cmd package list package | grep -E '(bin.mt.plus.termex|com.android.append)'`" != "" || -d "$MODPATH/system/priv-app/zygisk" ]];then
	rm -rf /data/adb/modules/*/system/priv-app/zygisk/zygisk.apk /data/adb/modules/*/system/priv-app/*/termux.apk
	if [[ "$(is_system_path "bin.mt.plus.termex")" = "true" || "$(is_system_path "com.android.append")" = "true" ]];then
		disable_apps "com.android.append" "disable"
		disable_apps "bin.mt.plus.termex" "disable"
	fi
fi




