id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

function method_kill_apps(){
local packagename="$i"
test "${packagename}" = "" && return 0
if test $(show_value "chattr锁定") == 是 ;then
	find /data/user/*/$packagename /data/data/$packagename /data/media/*/Android/data/$packagename -iname "splash" -type d -o -iname "ksadsdk" -type d -o -iname "trackLog" -type d -o -iname "zeuslogs" -type d -o -iname "pangle_p" -type d -o -iname "app_adnet" -type d -o -iname "pangle_com.byted.pangle" -type d -o -iname "app_baidu_ad_sdk" -type d  2>/dev/null | while read path ;do
		X_file "${path}"
	done
else 
	find /data/user/*/$packagename /data/data/$packagename /data/media/*/Android/data/$packagename -iname "splash" -type d -o -iname "ksadsdk" -type d -o -iname "trackLog" -type d -o -iname "zeuslogs" -type d -o -iname "pangle_p" -type d -o -iname "app_adnet" -type d -o -iname "pangle_com.byted.pangle" -type d -o -iname "app_baidu_ad_sdk" -type d 2>/dev/null | while read path ;do
		mkdir_file "${path}"
	done
fi
if test -d "/data/user/0/$packagename/" ;then
	rm -rf /data/user/0/$packagename/files/*send_data*
	rm -rf /data/user/0/$packagename/files/*.log
fi
}

local apps="
com.baidu.tieba
com.baidu.tieba_mini
"
for i in $apps 
do
	method_kill_apps "$i"
done

