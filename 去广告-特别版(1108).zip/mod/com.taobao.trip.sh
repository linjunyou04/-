id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh


find /data/user/*/com.taobao.trip /data/data/com.taobao.trip /data/media/*/Android/data/com.taobao.trip -iname "app_tombstone" -type d -o -iname "AMap" -type d -o -iname "*_splash" -type d 2>/dev/null | while read adfile
do
	mkdir_file $adfile 2>/dev/null 
done
